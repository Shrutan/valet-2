import React, { useState, useEffect } from "react";
import { Smartphone, LayoutDashboard, QrCode, BarChart3, ChevronDown, CheckCircle, Car, Lock, Unlock, Shield, LogOut, Loader2, Key } from "lucide-react";
import GuestPortal from "./components/GuestPortal";
import ManagerDashboard from "./components/ManagerDashboard";
import TableQRHub from "./components/TableQRHub";
import AnalyticsPanel from "./components/AnalyticsPanel";

type AppRole = "guest" | "manager" | "qrplayground" | "analytics";

export default function App() {
  const [activeRole, setActiveRole] = useState<AppRole>("qrplayground");
  const [simulateTableNumber, setSimulateTableNumber] = useState<string>("");
  const [ticketId, setTicketId] = useState<string | null>(null);
  const [isDevControlsOpen, setIsDevControlsOpen] = useState(true);

  // Device & Authorization state
  const [deviceId, setDeviceId] = useState<string>("");
  const [authorizedRole, setAuthorizedRole] = useState<AppRole | "guest">("guest");
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [passcode, setPasscode] = useState("");
  const [loginError, setLoginError] = useState("");
  const [loginSuccess, setLoginSuccess] = useState(false);
  const [isQrScannedUrl, setIsQrScannedUrl] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Register device on mount & handle routing
  useEffect(() => {
    // Generate or fetch deviceId
    let id = localStorage.getItem("smartvalet_device_id");
    if (!id) {
      id = "client-" + Math.random().toString(36).substring(2, 11);
      localStorage.setItem("smartvalet_device_id", id);
    }
    setDeviceId(id);

    const params = new URLSearchParams(window.location.search);
    const view = params.get("view");
    const table = params.get("table");

    const hasViewParam = view === "checkin" || view === "tablerequest";
    setIsQrScannedUrl(hasViewParam);

    const registerDevice = async () => {
      try {
        setIsLoading(true);
        // If they scanned a QR code, force guest role registry, otherwise check current server role
        const res = await fetch("/api/admin/devices/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            deviceId: id,
            name: hasViewParam ? "Customer Mobile QR" : "Admin Console",
            forceRole: hasViewParam ? "guest" : undefined
          })
        });
        if (res.ok) {
          const data = await res.json();
          setAuthorizedRole(data.role);
          
          // If customer scanned QR, force guest view
          if (hasViewParam) {
            setActiveRole("guest");
            if (view === "tablerequest" && table) {
              setSimulateTableNumber(table);
            }
          } else {
            // Otherwise default to their authorized role or playground
            setActiveRole(data.role === "guest" ? "qrplayground" : data.role);
          }
        }
      } catch (err) {
        console.error("Device registration failed", err);
        if (hasViewParam) {
          setActiveRole("guest");
          if (view === "tablerequest" && table) {
            setSimulateTableNumber(table);
          }
        }
      } finally {
        setIsLoading(false);
      }
    };

    registerDevice();
  }, []);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    try {
      const response = await fetch("/api/admin/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ passcode, deviceId, name: "Master Terminal" })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        setLoginSuccess(true);
        setAuthorizedRole("manager");
        setActiveRole("manager");
        setLoginError("");
        setTimeout(() => {
          setIsLoginOpen(false);
          setLoginSuccess(false);
          setPasscode("");
        }, 1200);
      } else {
        setLoginError(data.error || "Incorrect passcode. Try '1234'");
      }
    } catch (err) {
      setLoginError("Connection failed");
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/admin/devices/assign", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetDeviceId: deviceId, role: "guest" })
      });
      setAuthorizedRole("guest");
      setActiveRole("qrplayground");
    } catch (err) {
      console.error(err);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] flex flex-col items-center justify-center text-slate-300">
        <Loader2 className="w-8 h-8 text-indigo-500 animate-spin mb-3" />
        <p className="text-sm text-slate-400 font-medium">Synchronizing Secure Session...</p>
      </div>
    );
  }

  // Show dev controls only if they aren't on a QR-scanned link and they are authorized as an admin (non-guest)
  const showDevPanel = !isQrScannedUrl && authorizedRole !== "guest";

  return (
    <div className="min-h-screen bg-[#0A0A0B] flex flex-col font-sans text-slate-300">
      {/* Floating Demonstration Control Panel */}
      {showDevPanel && (
        <div className="bg-[#141416] border-b border-slate-800 text-white z-40">
          <div className="max-w-7xl mx-auto px-4 md:px-6">
            <div className="flex justify-between items-center py-3">
              <div className="flex items-center space-x-2.5">
                <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
                <span className="font-display font-extrabold text-sm tracking-tight text-white">SmartValet Kiosk Demo</span>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setIsDevControlsOpen(!isDevControlsOpen)}
                  className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-3 py-1.5 rounded-lg flex items-center space-x-1 transition cursor-pointer"
                >
                  <span>{isDevControlsOpen ? "Hide Controls" : "Show Controls"}</span>
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isDevControlsOpen ? "rotate-180" : ""}`} />
                </button>
              </div>
            </div>

            {/* Dev control options */}
            {isDevControlsOpen && (
              <div className="py-4 border-t border-slate-800/60 grid grid-cols-2 md:grid-cols-4 gap-2 transition-all duration-300 pb-5">
                <button
                  onClick={() => {
                    setActiveRole("qrplayground");
                    setSimulateTableNumber("");
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-2 border cursor-pointer ${
                    activeRole === "qrplayground"
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-900/20"
                      : "bg-[#1C1C1F] hover:bg-slate-800 text-slate-300 border-slate-800"
                  }`}
                >
                  <QrCode className="w-4 h-4" />
                  <span>1. QR Playground</span>
                </button>

                <button
                  onClick={() => {
                    setActiveRole("guest");
                    setSimulateTableNumber("");
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-2 border cursor-pointer ${
                    activeRole === "guest" && !simulateTableNumber
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-900/20"
                      : "bg-[#1C1C1F] hover:bg-slate-800 text-slate-300 border-slate-800"
                  }`}
                >
                  <Smartphone className="w-4 h-4" />
                  <span>2. Guest Kiosk</span>
                </button>

                <button
                  onClick={() => {
                    setActiveRole("manager");
                    setSimulateTableNumber("");
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-2 border cursor-pointer ${
                    activeRole === "manager"
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-900/20"
                      : "bg-[#1C1C1F] hover:bg-slate-800 text-slate-300 border-slate-800"
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  <span>3. Valet Dashboard</span>
                </button>

                <button
                  onClick={() => {
                    setActiveRole("analytics");
                    setSimulateTableNumber("");
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-2 border cursor-pointer ${
                    activeRole === "analytics"
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-900/20"
                      : "bg-[#1C1C1F] hover:bg-slate-800 text-slate-300 border-slate-800"
                  }`}
                >
                  <BarChart3 className="w-4 h-4" />
                  <span>4. SaaS Analytics</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Main Viewport Container */}
      <div className="flex-1 w-full max-w-7xl mx-auto py-8 px-4 sm:px-6">
        {activeRole === "qrplayground" && (
          <TableQRHub
            onSimulateCheckin={() => {
              setActiveRole("guest");
              setSimulateTableNumber("");
            }}
            onSimulateTableScan={(tableNum) => {
              setSimulateTableNumber(tableNum);
              setActiveRole("guest");
            }}
          />
        )}

        {activeRole === "guest" && (
          <div className="py-4">
            <GuestPortal
              initialTicketId={ticketId}
              onTicketIdChange={setTicketId}
              simulateTableNumber={simulateTableNumber}
            />
          </div>
        )}

        {activeRole === "manager" && <ManagerDashboard />}

        {activeRole === "analytics" && <AnalyticsPanel currentDeviceId={deviceId} />}
      </div>

      {/* Elegant Footer with Master/Staff Authorization Lock */}
      <footer className="py-8 px-6 border-t border-slate-900 text-xs text-slate-600 mt-auto bg-[#0E0E10]/30">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center space-x-2 text-slate-500">
            <Car className="w-4 h-4 text-slate-600" />
            <p>© 2026 SmartValet Hub • Multi-Role Restaurant SaaS Platform</p>
          </div>
          
          <div className="flex items-center space-x-3">
            {authorizedRole === "guest" ? (
              <button
                onClick={() => {
                  setLoginError("");
                  setIsLoginOpen(true);
                }}
                className="flex items-center space-x-1.5 hover:text-indigo-400 text-slate-500 font-bold transition cursor-pointer bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 hover:border-indigo-500/30"
              >
                <Lock className="w-3.5 h-3.5 text-slate-500" />
                <span>Admin Login / Lock Kiosk</span>
              </button>
            ) : (
              <div className="flex items-center space-x-3 text-slate-400">
                <span className="flex items-center space-x-1.5 text-indigo-400 font-semibold bg-indigo-500/10 px-2.5 py-1.5 rounded-lg border border-indigo-500/20">
                  <Shield className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                  <span className="uppercase tracking-wider text-[10px]">Staff Authorized</span>
                </span>
                <button
                  onClick={handleLogout}
                  className="flex items-center space-x-1.5 hover:text-rose-400 text-slate-500 font-bold transition cursor-pointer bg-rose-950/10 px-3 py-1.5 rounded-lg border border-rose-950/20 hover:border-rose-500/30"
                >
                  <LogOut className="w-3.5 h-3.5 text-rose-400" />
                  <span>Lock Console</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </footer>

      {/* Admin Passcode Modal */}
      {isLoginOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#141417] border border-slate-800 p-6 rounded-2xl max-w-sm w-full shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
            <div className="text-center space-y-2 mb-6">
              <div className="mx-auto w-12 h-12 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/20">
                <Key className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white tracking-tight">Unlock Master Console</h3>
              <p className="text-xs text-slate-500">
                Enter the secret passcode to authorize this device and unlock full administrative capabilities.
              </p>
            </div>

            <form onSubmit={handleVerify} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Passcode
                </label>
                <input
                  type="password"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  placeholder="••••"
                  className="w-full text-center tracking-[0.5em] font-mono text-lg py-3 bg-[#0E0E10] border border-slate-800 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all placeholder:tracking-normal"
                  autoFocus
                  required
                />
              </div>

              {loginError && (
                <div className="text-xs text-rose-400 text-center bg-rose-950/20 py-2 rounded-lg border border-rose-950/40">
                  {loginError}
                </div>
              )}

              {loginSuccess && (
                <div className="text-xs text-emerald-400 text-center bg-emerald-950/20 py-2 rounded-lg border border-emerald-950/40 flex items-center justify-center space-x-1">
                  <CheckCircle className="w-4 h-4 animate-bounce" />
                  <span>Passcode Verified! Welcome, Master.</span>
                </div>
              )}

              <div className="flex space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsLoginOpen(false)}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-lg text-xs transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loginSuccess}
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition cursor-pointer border border-indigo-500/30"
                >
                  {loginSuccess ? "Unlocking..." : "Verify Passcode"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
