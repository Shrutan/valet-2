export type CarStatus =
  | "CHECKED_IN"
  | "RETRIEVAL_REQUESTED"
  | "RETRIEVAL_IN_PROGRESS"
  | "READY"
  | "DELIVERED";

export interface CarEntry {
  id: string;
  plate: string;
  color: string;
  brand: string;
  model: string;
  name?: string;
  phone?: string;
  tableNumber?: string;
  keyTag?: string;
  status: CarStatus;
  createdAt: string;
  requestedAt?: string;
  readyAt?: string;
  deliveredAt?: string;
}

export interface ValetAnalytics {
  totalCarsToday: number;
  activeCars: number;
  requestedCars: number;
  averageRetrievalTimeMinutes: number; // calculated from requestedAt to readyAt
  carsByStatus: Record<CarStatus, number>;
}
