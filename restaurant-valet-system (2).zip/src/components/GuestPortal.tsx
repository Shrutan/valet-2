import React, { useState, useEffect } from "react";
import { Car, Send, CheckCircle, Clock, AlertCircle, Search, Table, Phone, User, QrCode } from "lucide-react";
import { CarEntry, CarStatus } from "../types";

interface GuestPortalProps {
  initialTicketId?: string | null;
  onTicketIdChange?: (id: string | null) => void;
  simulateTableNumber?: string;
}

export default function GuestPortal({
  initialTicketId,
  onTicketIdChange,
  simulateTableNumber,
}: GuestPortalProps) {
  // Navigation / View state
  const [activeTab, setActiveTab] = useState<"checkin" | "tracker" | "lookup">("checkin");

  // Check-in Form state
  const [plate, setPlate] = useState("");
  const [color, setColor] = useState("");
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [tableNumber, setTableNumber] = useState(simulateTableNumber || "");

  // Lookup state
  const [lookupQuery, setLookupQuery] = useState("");
  const [lookupResults, setLookupResults] = useState<CarEntry[]>([]);
  const [lookupError, setLookupError] = useState("");
  const [isSearching, setIsSearching] = useState(false);

  // Active tracking state
  const [ticketId, setTicketId] = useState<string | null>(initialTicketId || localStorage.getItem("guest_ticket_id"));
  const [trackedCar, setTrackedCar] = useState<CarEntry | null>(null);
  const [trackerError, setTrackerError] = useState("");
  const [isLoadingTracker, setIsLoadingTracker] = useState(false);

  // Form submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  // Sync state with parent and localStorage
  useEffect(() => {
    if (ticketId) {
      localStorage.setItem("guest_ticket_id", ticketId);
      if (onTicketIdChange) onTicketIdChange(ticketId);
      setActiveTab("tracker");
    } else {
      localStorage.removeItem("guest_ticket_id");
      if (onTicketIdChange) onTicketIdChange(null);
    }
  }, [ticketId]);

  // Update table number if simulated
  useEffect(() => {
    if (simulateTableNumber) {
      setTableNumber(simulateTableNumber);
      // If table QR scanned, go to lookup/retrieval tab if they have a ticket, else prefill in checkin
      if (ticketId) {
        setActiveTab("tracker");
      } else {
        setActiveTab("checkin");
      }
    }
  }, [simulateTableNumber, ticketId]);

  // Poll car status from backend when tracking a ticket
  useEffect(() => {
    if (!ticketId || activeTab !== "tracker") return;

    const fetchCarStatus = async () => {
      try {
        const response = await fetch(`/api/cars/${ticketId}`);
        if (!response.ok) {
          throw new Error("Valet ticket not found or expired.");
        }
        const data = await response.json();
        setTrackedCar(data);
        setTrackerError("");
      } catch (err: any) {
        setTrackerError(err.message);
        setTrackedCar(null);
      }
    };

    setIsLoadingTracker(true);
    fetchCarStatus().finally(() => setIsLoadingTracker(false));

    // Poll every 4 seconds for live updates
    const interval = setInterval(fetchCarStatus, 4000);
    return () => clearInterval(interval);
  }, [ticketId, activeTab]);

  // Submit Check-in Form
  const handleCheckinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError("");
    setIsSubmitting(true);

    if (!plate || !color || !brand || !model) {
      setSubmitError("Please fill out all required fields.");
      setIsSubmitting(false);
      return;
    }

    if (plate.length < 4 || isNaN(Number(plate))) {
      setSubmitError("Please enter exactly the last 4 digits of your license plate.");
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await fetch("/api/cars/checkin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          plate,
          color,
          brand,
          model,
          name,
          phone,
          tableNumber,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to register car with valet stand.");
      }

      const newCar: CarEntry = await response.json();
      setTicketId(newCar.id);
      
      // Clear form
      setPlate("");
      setColor("");
      setBrand("");
      setModel("");
      setName("");
      setPhone("");
      setTableNumber("");
    } catch (err: any) {
      setSubmitError(err.message || "Something went wrong. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Search/Lookup a car
  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLookupError("");
    setLookupResults([]);
    
    if (!lookupQuery) return;
    setIsSearching(true);

    try {
      const response = await fetch("/api/cars/lookup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: lookupQuery }),
      });

      if (!response.ok) {
        throw new Error("Search failed.");
      }

      const results = await response.json();
      setLookupResults(results);
      if (results.length === 0) {
        setLookupError("No active valet ticket found matching that plate or ticket ID.");
      }
    } catch (err: any) {
      setLookupError(err.message || "Error searching for ticket.");
    } finally {
      setIsSearching(false);
    }
  };

  // Request Retrieval
  const handleRequestRetrieval = async (id: string) => {
    try {
      const response = await fetch(`/api/cars/${id}/request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tableNumber: tableNumber || undefined }),
      });

      if (!response.ok) {
        throw new Error("Failed to request valet retrieval.");
      }

      const updatedCar = await response.json();
      if (ticketId === id) {
        setTrackedCar(updatedCar);
      } else {
        setTicketId(id);
      }
      setActiveTab("tracker");
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Common Car Brands for Auto-suggest buttons
  const commonBrands = ["Toyota", "Tata", "Hyundai", "Mahindra"];
  // Common Colors
  const commonColors = ["Black", "White", "Silver", "Gray", "Red", "Blue", "Brown"];

  const getStatusStepClass = (stepStatus: CarStatus, currentStatus: CarStatus) => {
    const statusOrder: CarStatus[] = [
      "CHECKED_IN",
      "RETRIEVAL_REQUESTED",
      "RETRIEVAL_IN_PROGRESS",
      "READY",
      "DELIVERED",
    ];
    
    const currentIndex = statusOrder.indexOf(currentStatus);
    const stepIndex = statusOrder.indexOf(stepStatus);

    if (stepIndex < currentIndex) {
      return "bg-emerald-600 text-white border-emerald-600"; // completed
    } else if (stepIndex === currentIndex) {
      return "bg-indigo-600 text-white border-indigo-600 animate-pulse ring-4 ring-indigo-100"; // active
    } else {
      return "bg-white text-slate-400 border-slate-200"; // pending
    }
  };

  const getStatusTextClass = (stepStatus: CarStatus, currentStatus: CarStatus) => {
    const statusOrder: CarStatus[] = [
      "CHECKED_IN",
      "RETRIEVAL_REQUESTED",
      "RETRIEVAL_IN_PROGRESS",
      "READY",
      "DELIVERED",
    ];
    
    const currentIndex = statusOrder.indexOf(currentStatus);
    const stepIndex = statusOrder.indexOf(stepStatus);

    if (stepIndex < currentIndex) {
      return "text-slate-800 font-medium";
    } else if (stepIndex === currentIndex) {
      return "text-indigo-600 font-bold";
    } else {
      return "text-slate-400";
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto bg-[#141416] rounded-2xl shadow-2xl border border-slate-800 overflow-hidden" id="guest-portal-container">
      {/* Top Banner / Tab Navigation */}
      <div className="bg-[#0E0E10] text-white px-6 pt-6 pb-5 relative border-b border-slate-800/80">
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-2.5 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/10">
            <Car className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-display font-bold tracking-tight text-white">SmartValet Guest</h1>
            <p className="text-xs text-slate-500">Zero-Wait Valet Service</p>
          </div>
        </div>

        {/* Custom Tabs */}
        <div className="flex bg-[#0A0A0B] p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab("checkin")}
            className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg transition-all duration-200 cursor-pointer ${
              activeTab === "checkin"
                ? "bg-slate-800 text-indigo-400 shadow"
                : "text-slate-500 hover:text-slate-300"
            }`}
          >
            1. Drop-off Car
          </button>
          <button
            onClick={() => setActiveTab("tracker")}
            className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg transition-all duration-200 relative cursor-pointer ${
              activeTab === "tracker"
                ? "bg-slate-800 text-indigo-400 shadow"
                : "text-slate-500 hover:text-slate-300"
            }`}
          >
            2. Live Status
            {ticketId && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-indigo-500 rounded-full ring-2 ring-[#0A0A0B]" />
            )}
          </button>
          <button
            onClick={() => setActiveTab("lookup")}
            className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg transition-all duration-200 cursor-pointer ${
              activeTab === "lookup"
                ? "bg-slate-800 text-indigo-400 shadow"
                : "text-slate-500 hover:text-slate-300"
            }`}
          >
            Find My Ticket
          </button>
        </div>
      </div>

      <div className="p-6">
        {/* CHECKIN FORM VIEW */}
        {activeTab === "checkin" && (
          <div>
            <div className="mb-6">
              <h2 className="text-base font-display font-bold text-white mb-1">Check-In Your Car</h2>
              <p className="text-xs text-slate-400">
                Register your vehicle details with the valet stand. It takes less than 1 minute and saves you wait time later!
              </p>
            </div>

            {simulateTableNumber && (
              <div className="mb-4 p-3 bg-indigo-950/20 border border-indigo-500/20 rounded-xl flex items-start space-x-3 text-indigo-300 text-xs">
                <Table className="w-4 h-4 mt-0.5 flex-shrink-0 text-indigo-400" />
                <div>
                  <span className="font-semibold text-white">Table QR Active:</span> Pre-filling your location as <span className="font-bold underline text-indigo-400">Table {simulateTableNumber}</span>.
                </div>
              </div>
            )}

            <form onSubmit={handleCheckinSubmit} className="space-y-4">
              {/* LICENSE PLATE (LAST 4 DIGITS) */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5 flex justify-between">
                  <span>Car Plate (Last 4 Digits) <span className="text-rose-500">*</span></span>
                  <span className="text-[10px] text-slate-500 font-normal">Matches key tag</span>
                </label>
                <input
                  type="text"
                  maxLength={4}
                  required
                  placeholder="e.g. 5834"
                  value={plate}
                  onChange={(e) => setPlate(e.target.value.replace(/\D/g, ""))}
                  className="w-full px-4 py-3 bg-[#0E0E10] border border-slate-800 rounded-xl text-lg font-mono font-bold tracking-widest text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-center placeholder-slate-700"
                />
              </div>

              {/* BRAND / MODEL */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                    Brand/Make <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. BMW, Audi"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    className="w-full px-4 py-3 bg-[#0E0E10] border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all placeholder-slate-700"
                  />
                  {/* Suggestions */}
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {commonBrands.slice(0, 4).map((b) => (
                      <button
                        key={b}
                        type="button"
                        onClick={() => setBrand(b)}
                        className="text-[10px] px-2 py-0.5 bg-[#1C1C1F] hover:bg-slate-800 rounded text-slate-400 border border-slate-800/80 transition cursor-pointer"
                      >
                        {b}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                    Car Model <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. X5, Model Y"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="w-full px-4 py-3 bg-[#0E0E10] border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all placeholder-slate-700"
                  />
                </div>
              </div>

              {/* COLOR */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Car Color <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Midnight Black, Pearl White"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-full px-4 py-3 bg-[#0E0E10] border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all placeholder-slate-700"
                />
                {/* Suggestions */}
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {commonColors.slice(0, 5).map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className="text-[10px] px-2 py-0.5 bg-[#1C1C1F] hover:bg-slate-800 rounded text-slate-400 border border-slate-800/80 transition cursor-pointer"
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* OPTIONAL EXTRAS */}
              <div className="border-t border-slate-800/60 pt-4 mt-4 space-y-4">
                <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider block">
                  Optional Info (Speeds Up Retrieval)
                </span>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1 flex items-center space-x-1">
                      <User className="w-3 h-3 text-slate-500" />
                      <span>Name</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. John Doe"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3 py-2 bg-[#0E0E10] border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all placeholder-slate-700"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1 flex items-center space-x-1">
                      <Table className="w-3 h-3 text-slate-500" />
                      <span>Table Number</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 14"
                      value={tableNumber}
                      onChange={(e) => setTableNumber(e.target.value)}
                      className="w-full px-3 py-2 bg-[#0E0E10] border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all placeholder-slate-700"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1 flex items-center space-x-1">
                    <Phone className="w-3 h-3 text-slate-500" />
                    <span>Phone Number</span>
                  </label>
                  <input
                    type="tel"
                    placeholder="e.g. (555) 019-2834"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-[#0E0E10] border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all placeholder-slate-700"
                  />
                </div>
              </div>

              {submitError && (
                <div className="p-3 bg-rose-950/20 border border-rose-500/20 rounded-xl flex items-center space-x-2 text-rose-300 text-xs">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                  <span>{submitError}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white font-bold rounded-xl shadow-lg shadow-indigo-900/10 flex items-center justify-center space-x-2 transition-all cursor-pointer"
              >
                {isSubmitting ? (
                  <span>Registering Car...</span>
                ) : (
                  <>
                    <span>Submit & Get Digital Ticket</span>
                    <Send className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        {/* LIVE TRACKER VIEW */}
        {activeTab === "tracker" && (
          <div className="space-y-6">
            {!ticketId ? (
              <div className="text-center py-12 border-2 border-dashed border-slate-800 rounded-2xl">
                <Car className="w-12 h-12 text-slate-700 mx-auto mb-3" />
                <h3 className="font-bold text-white mb-1">No Active Ticket</h3>
                <p className="text-xs text-slate-500 max-w-xs mx-auto mb-4">
                  You haven't submitted a car details form yet, or your session has expired.
                </p>
                <button
                  onClick={() => setActiveTab("checkin")}
                  className="px-4 py-2 bg-[#1C1C1F] border border-slate-800 text-indigo-400 rounded-xl text-xs font-semibold hover:bg-slate-800 transition cursor-pointer"
                >
                  Go to Drop-off Form
                </button>
              </div>
            ) : isLoadingTracker && !trackedCar ? (
              <div className="text-center py-12">
                <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                <p className="text-xs text-slate-500">Loading your digital valet ticket...</p>
              </div>
            ) : trackerError ? (
              <div className="p-4 bg-rose-950/20 border border-rose-500/20 rounded-xl text-center">
                <AlertCircle className="w-8 h-8 text-rose-500 mx-auto mb-2" />
                <h4 className="font-bold text-rose-300 text-sm mb-1">Ticket Error</h4>
                <p className="text-xs text-rose-400 mb-4">{trackerError}</p>
                <button
                  onClick={() => setTicketId(null)}
                  className="px-3 py-1.5 bg-rose-950/30 hover:bg-rose-900 border border-rose-800 rounded-lg text-xs font-bold text-rose-300 transition"
                >
                  Clear Ticket & Restart
                </button>
              </div>
            ) : trackedCar ? (
              <div className="space-y-6">
                {/* DIGITAL PASS TICKET DESIGN */}
                <div className="relative bg-[#1C1C1F] border border-slate-800 rounded-2xl overflow-hidden p-5 shadow-inner">
                  {/* Notch cutouts for ticket look */}
                  <div className="absolute top-1/2 -left-3 w-6 h-6 bg-[#141416] border border-slate-800 rounded-full" />
                  <div className="absolute top-1/2 -right-3 w-6 h-6 bg-[#141416] border border-slate-800 rounded-full" />

                  <div className="flex justify-between items-start border-b border-dashed border-slate-800 pb-4 mb-4">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                        DIGITAL VALET TICKET
                      </span>
                      <h3 className="text-3xl font-mono font-extrabold text-white tracking-tight mt-0.5">
                        {trackedCar.id}
                      </h3>
                    </div>
                    <div className="bg-indigo-600 text-white px-3 py-1.5 rounded-lg font-mono text-xs font-bold tracking-wider">
                      TAG {trackedCar.keyTag || "Pending"}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-slate-500 block mb-0.5">Car Plate</span>
                      <span className="font-bold text-white font-mono text-sm tracking-wide">
                        [****] {trackedCar.plate}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block mb-0.5">Vehicle</span>
                      <span className="font-bold text-white">
                        {trackedCar.color} {trackedCar.brand} {trackedCar.model}
                      </span>
                    </div>
                    {trackedCar.name && (
                      <div>
                        <span className="text-slate-500 block mb-0.5">Guest Name</span>
                        <span className="font-bold text-slate-300">{trackedCar.name}</span>
                      </div>
                    )}
                    <div>
                      <span className="text-slate-500 block mb-0.5">Location</span>
                      <span className="font-bold text-indigo-400 flex items-center space-x-1">
                        <Table className="w-3.5 h-3.5 mr-1 inline" />
                        <span>{trackedCar.tableNumber ? `Table ${trackedCar.tableNumber}` : "Not Dining"}</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* CURRENT STATUS PANEL */}
                <div className="bg-[#1C1C1F] rounded-2xl p-4 border border-slate-800/80 flex items-center space-x-4">
                  {trackedCar.status === "CHECKED_IN" && (
                    <>
                      <div className="p-3 bg-amber-500/10 rounded-xl text-amber-400 flex-shrink-0">
                        <Clock className="w-6 h-6 animate-pulse" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-white text-sm">Car is Safely Parked</h4>
                        <p className="text-xs text-slate-400">
                          Enjoy your meal! Click the button below when you are 5-10 minutes from leaving.
                        </p>
                      </div>
                    </>
                  )}

                  {trackedCar.status === "RETRIEVAL_REQUESTED" && (
                    <>
                      <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400 flex-shrink-0">
                        <Clock className="w-6 h-6 animate-pulse" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-white text-sm">Retrieval Requested</h4>
                        <p className="text-xs text-slate-400">
                          Valet crew has been alerted. We are preparing to retrieve your car.
                        </p>
                      </div>
                    </>
                  )}

                  {trackedCar.status === "RETRIEVAL_IN_PROGRESS" && (
                    <>
                      <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400 flex-shrink-0">
                        <Car className="w-6 h-6 animate-bounce" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-white text-sm">Staff Fetching Your Car</h4>
                        <p className="text-xs text-slate-400">
                          Valet team is bringing your car to the main exit. Estimated wait: <span className="font-bold text-indigo-300">2-4 mins</span>.
                        </p>
                      </div>
                    </>
                  )}

                  {trackedCar.status === "READY" && (
                    <>
                      <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-400 flex-shrink-0">
                        <CheckCircle className="w-6 h-6 animate-pulse" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-emerald-300 text-sm">Car Ready at Exit!</h4>
                        <p className="text-xs text-emerald-400">
                          Your car is waiting for you at the restaurant exit point. Please show ticket <span className="font-bold">{trackedCar.id}</span> to the staff.
                        </p>
                      </div>
                    </>
                  )}

                  {trackedCar.status === "DELIVERED" && (
                    <>
                      <div className="p-3 bg-slate-800 rounded-xl text-slate-400 flex-shrink-0">
                        <CheckCircle className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-white text-sm">Delivered & Closed</h4>
                        <p className="text-xs text-slate-400">
                          Your car was returned safely. Thank you for dining with us! Have a safe drive.
                        </p>
                      </div>
                    </>
                  )}
                </div>

                {/* THE "MEAL DONE" BUTTON (Only visible for parked cars) */}
                {trackedCar.status === "CHECKED_IN" && (
                  <button
                    onClick={() => handleRequestRetrieval(trackedCar.id)}
                    className="w-full py-4 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-base rounded-2xl shadow-lg shadow-indigo-900/20 flex flex-col items-center justify-center transition cursor-pointer"
                  >
                    <span>Meal Done / Get My Car</span>
                    <span className="text-[10px] font-normal text-indigo-200 mt-0.5">
                      Triggers instant valet retrieval (5-10 min head start)
                    </span>
                  </button>
                )}

                {/* VISUAL STEPPER PROCESS */}
                <div className="border-t border-slate-800 pt-6">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 text-center">
                    Retrieval Progress
                  </h4>

                  <div className="relative">
                    {/* Stepper bar */}
                    <div className="absolute left-[17px] top-2 bottom-2 w-0.5 bg-slate-800" />

                    <div className="space-y-5 relative">
                      {/* Step 1: Checked In */}
                      <div className="flex items-start space-x-3.5">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold border-2 flex-shrink-0 transition-all ${
                          trackedCar.status === "CHECKED_IN" 
                            ? "bg-indigo-600/20 text-indigo-400 border-indigo-500/30 ring-2 ring-indigo-500/20" 
                            : "bg-[#1C1C1F] text-slate-500 border-slate-800"
                        }`}>
                          P
                        </div>
                        <div className="pt-1.5">
                          <h5 className={`text-xs font-semibold ${trackedCar.status === "CHECKED_IN" ? "text-indigo-400 font-bold" : "text-slate-400"}`}>
                            Car Safely Parked
                          </h5>
                          <p className="text-[10px] text-slate-500">Key associated with tag #{trackedCar.keyTag || "TBD"}</p>
                        </div>
                      </div>

                      {/* Step 2: Requested */}
                      <div className="flex items-start space-x-3.5">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold border-2 flex-shrink-0 transition-all ${
                          trackedCar.status === "RETRIEVAL_REQUESTED" 
                            ? "bg-indigo-600/20 text-indigo-400 border-indigo-500/30 ring-2 ring-indigo-500/20" 
                            : trackedCar.requestedAt ? "bg-emerald-600/20 text-emerald-400 border-emerald-500/30" : "bg-[#1C1C1F] text-slate-500 border-slate-800"
                        }`}>
                          R
                        </div>
                        <div className="pt-1.5">
                          <h5 className={`text-xs font-semibold ${trackedCar.status === "RETRIEVAL_REQUESTED" ? "text-indigo-400 font-bold" : "text-slate-400"}`}>
                            Retrieval Requested
                          </h5>
                          <p className="text-[10px] text-slate-500">
                            {trackedCar.requestedAt
                              ? `Requested at ${new Date(trackedCar.requestedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
                              : "Waiting for request"}
                          </p>
                        </div>
                      </div>

                      {/* Step 3: In Progress */}
                      <div className="flex items-start space-x-3.5">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold border-2 flex-shrink-0 transition-all ${
                          trackedCar.status === "RETRIEVAL_IN_PROGRESS" 
                            ? "bg-indigo-600/20 text-indigo-400 border-indigo-500/30 ring-2 ring-indigo-500/20" 
                            : (trackedCar.status === "READY" || trackedCar.status === "DELIVERED") ? "bg-emerald-600/20 text-emerald-400 border-emerald-500/30" : "bg-[#1C1C1F] text-slate-500 border-slate-800"
                        }`}>
                          F
                        </div>
                        <div className="pt-1.5">
                          <h5 className={`text-xs font-semibold ${trackedCar.status === "RETRIEVAL_IN_PROGRESS" ? "text-indigo-400 font-bold" : "text-slate-400"}`}>
                            Staff Fetching Car
                          </h5>
                          <p className="text-[10px] text-slate-500">Valet teammate is retrieving keys and vehicle</p>
                        </div>
                      </div>

                      {/* Step 4: Ready */}
                      <div className="flex items-start space-x-3.5">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold border-2 flex-shrink-0 transition-all ${
                          trackedCar.status === "READY" 
                            ? "bg-indigo-600/20 text-indigo-400 border-indigo-500/30 ring-2 ring-indigo-500/20" 
                            : trackedCar.status === "DELIVERED" ? "bg-emerald-600/20 text-emerald-400 border-emerald-500/30" : "bg-[#1C1C1F] text-slate-500 border-slate-800"
                        }`}>
                          G
                        </div>
                        <div className="pt-1.5">
                          <h5 className={`text-xs font-semibold ${trackedCar.status === "READY" ? "text-indigo-400 font-bold" : "text-slate-400"}`}>
                            Ready at Exit Point
                          </h5>
                          <p className="text-[10px] text-slate-500">Parked in the pick-up lane, ready to go</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <button
                    onClick={() => {
                      if (confirm("Are you sure you want to clear your local session ticket?")) {
                        setTicketId(null);
                        setTrackedCar(null);
                        setActiveTab("checkin");
                      }
                    }}
                    className="text-xs text-rose-400 hover:text-rose-300 underline font-medium cursor-pointer"
                  >
                    Exit & Clear Ticket Session
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        )}

        {/* LOOKUP TICKET VIEW */}
        {activeTab === "lookup" && (
          <div>
            <div className="mb-6">
              <h2 className="text-base font-display font-bold text-white mb-1">Find Valet Ticket</h2>
              <p className="text-xs text-slate-400">
                Did you drop your car off without scanning the code first, or lost your ticket page? Enter your plate last 4 digits or ticket ID to link it.
              </p>
            </div>

            <form onSubmit={handleLookup} className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Plate Digits or Ticket ID (e.g. 2311 or T-1003)
                </label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    required
                    placeholder="e.g. 5834"
                    value={lookupQuery}
                    onChange={(e) => setLookupQuery(e.target.value)}
                    className="flex-1 px-4 py-2 bg-[#0E0E10] border border-slate-800 rounded-xl text-sm font-semibold uppercase text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all placeholder-slate-700"
                  />
                  <button
                    type="submit"
                    disabled={isSearching}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold flex items-center space-x-1.5 transition cursor-pointer"
                  >
                    <Search className="w-4 h-4" />
                    <span>{isSearching ? "Searching..." : "Search"}</span>
                  </button>
                </div>
              </div>

              {lookupError && (
                <div className="p-3 bg-rose-950/20 border border-rose-500/20 rounded-xl flex items-center space-x-2 text-rose-300 text-xs">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                  <span>{lookupError}</span>
                </div>
              )}
            </form>

            {lookupResults.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Matching Active Vehicles
                </h3>

                {lookupResults.map((car) => (
                  <div
                    key={car.id}
                    className="p-4 bg-[#1C1C1F] border border-slate-800 rounded-xl flex justify-between items-center hover:border-slate-700 transition"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-mono font-extrabold text-white text-sm">{car.id}</span>
                        <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded font-bold">
                          {car.status.replace("_", " ")}
                        </span>
                      </div>
                      <p className="text-xs font-medium text-slate-300 mt-1">
                        {car.color} {car.brand} {car.model}
                      </p>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">
                        Plate: [****] {car.plate} | Key Tag: {car.keyTag || "Unassigned"}
                      </p>
                    </div>

                    <div className="flex flex-col space-y-1.5">
                      <button
                        onClick={() => {
                          setTicketId(car.id);
                          setActiveTab("tracker");
                        }}
                        className="px-3 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded text-xs font-bold transition cursor-pointer"
                      >
                        Track Status
                      </button>

                      {car.status === "CHECKED_IN" && (
                        <button
                          onClick={() => handleRequestRetrieval(car.id)}
                          className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-xs font-bold transition cursor-pointer"
                        >
                          Request Retrieval
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer Branding */}
      <div className="border-t border-slate-800/60 py-3 px-6 bg-[#0E0E10] flex justify-between items-center text-[10px] text-slate-500 font-medium">
        <span>Powered by SmartValet SaaS</span>
        <span>Verified Secure Connection</span>
      </div>
    </div>
  );
}
