import express from "express";
import path from "path";
import fs from "fs/promises";
import { createServer as createViteServer } from "vite";

const PORT = 3000;
const DATA_FILE = path.join(process.cwd(), "data", "cars.json");

// Ensure data directory and file exist
async function initStorage() {
  try {
    await fs.mkdir(path.join(process.cwd(), "data"), { recursive: true });
    try {
      await fs.access(DATA_FILE);
    } catch {
      // Seed with some initial data for easy demonstration on startup
      const initialSeed: CarEntry[] = [
        {
          id: "T-1001",
          plate: "4521",
          color: "Deep Black",
          brand: "Audi",
          model: "A6",
          name: "Sarah Jenkins",
          phone: "+1 (555) 019-2834",
          tableNumber: "14",
          keyTag: "101",
          status: "CHECKED_IN",
          createdAt: new Date(Date.now() - 45 * 60000).toISOString(),
        },
        {
          id: "T-1002",
          plate: "8890",
          color: "Pearl White",
          brand: "Tesla",
          model: "Model Y",
          name: "David Chen",
          phone: "+1 (555) 014-9921",
          tableNumber: "8",
          keyTag: "102",
          status: "RETRIEVAL_REQUESTED",
          createdAt: new Date(Date.now() - 60 * 60000).toISOString(),
          requestedAt: new Date(Date.now() - 4 * 60000).toISOString(),
        },
        {
          id: "T-1003",
          plate: "2311",
          color: "Metallic Silver",
          brand: "BMW",
          model: "530i",
          name: "Elena Rostova",
          phone: "+1 (555) 017-8833",
          tableNumber: "22",
          keyTag: "103",
          status: "RETRIEVAL_IN_PROGRESS",
          createdAt: new Date(Date.now() - 75 * 60000).toISOString(),
          requestedAt: new Date(Date.now() - 8 * 60000).toISOString(),
        },
        {
          id: "T-1004",
          plate: "7721",
          color: "Cherry Red",
          brand: "Porsche",
          model: "Macan",
          name: "Marcus Aurelius",
          phone: "+1 (555) 012-3456",
          tableNumber: "Bar-3",
          keyTag: "104",
          status: "READY",
          createdAt: new Date(Date.now() - 90 * 60000).toISOString(),
          requestedAt: new Date(Date.now() - 10 * 60000).toISOString(),
          readyAt: new Date(Date.now() - 2 * 60000).toISOString(),
        }
      ];
      await fs.writeFile(DATA_FILE, JSON.stringify(initialSeed, null, 2));
    }
  } catch (err) {
    console.error("Failed to initialize storage:", err);
  }
}

interface CarEntry {
  id: string;
  plate: string;
  color: string;
  brand: string;
  model: string;
  name?: string;
  phone?: string;
  tableNumber?: string;
  keyTag?: string;
  status: "CHECKED_IN" | "RETRIEVAL_REQUESTED" | "RETRIEVAL_IN_PROGRESS" | "READY" | "DELIVERED";
  createdAt: string;
  requestedAt?: string;
  readyAt?: string;
  deliveredAt?: string;
}

async function getCars(): Promise<CarEntry[]> {
  try {
    const data = await fs.readFile(DATA_FILE, "utf-8");
    return JSON.parse(data);
  } catch {
    return [];
  }
}

async function saveCars(cars: CarEntry[]): Promise<void> {
  await fs.writeFile(DATA_FILE, JSON.stringify(cars, null, 2));
}

const SETTINGS_FILE = path.join(process.cwd(), "data", "settings.json");

interface DeviceAuthorization {
  deviceId: string;
  name: string;
  role: "guest" | "manager" | "qrplayground" | "analytics";
  lastActive: string;
}

interface AppSettings {
  adminPasscode: string;
  devices: DeviceAuthorization[];
}

async function getSettings(): Promise<AppSettings> {
  try {
    const data = await fs.readFile(SETTINGS_FILE, "utf-8");
    return JSON.parse(data);
  } catch {
    const defaultSettings: AppSettings = {
      adminPasscode: "1234",
      devices: [],
    };
    try {
      await fs.mkdir(path.join(process.cwd(), "data"), { recursive: true });
      await fs.writeFile(SETTINGS_FILE, JSON.stringify(defaultSettings, null, 2));
    } catch {}
    return defaultSettings;
  }
}

async function saveSettings(settings: AppSettings): Promise<void> {
  await fs.writeFile(SETTINGS_FILE, JSON.stringify(settings, null, 2));
}

async function startServer() {
  await initStorage();
  const app = express();
  app.use(express.json());

  // API Routes

  // GET all cars
  app.get("/api/cars", async (req, res) => {
    try {
      const cars = await getCars();
      res.json(cars);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET a single car by ID
  app.get("/api/cars/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const cars = await getCars();
      const car = cars.find((c) => c.id === id);
      if (!car) {
        return res.status(404).json({ error: "Car not found" });
      }
      res.json(car);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST check-in a new car
  app.post("/api/cars/checkin", async (req, res) => {
    try {
      const { plate, color, brand, model, name, phone, tableNumber } = req.body;
      
      if (!plate || !color || !brand || !model) {
        return res.status(400).json({ error: "Required fields missing" });
      }

      const cars = await getCars();
      
      // Calculate next ticket number
      const lastTicket = cars.reduce((max, car) => {
        const num = parseInt(car.id.replace("T-", ""), 10);
        return !isNaN(num) && num > max ? num : max;
      }, 1000);
      const ticketId = `T-${lastTicket + 1}`;

      const newCar: CarEntry = {
        id: ticketId,
        plate: plate.trim().slice(-4),
        color: color.trim(),
        brand: brand.trim(),
        model: model.trim(),
        name: name?.trim() || "",
        phone: phone?.trim() || "",
        tableNumber: tableNumber?.trim() || "",
        status: "CHECKED_IN",
        createdAt: new Date().toISOString(),
      };

      cars.push(newCar);
      await saveCars(cars);
      res.status(201).json(newCar);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST request valet retrieval
  app.post("/api/cars/:id/request", async (req, res) => {
    try {
      const { id } = req.params;
      const { tableNumber } = req.body;
      const cars = await getCars();
      const index = cars.findIndex((c) => c.id === id);
      if (index === -1) {
        return res.status(404).json({ error: "Car not found" });
      }

      const car = cars[index];
      car.status = "RETRIEVAL_REQUESTED";
      car.requestedAt = new Date().toISOString();
      if (tableNumber) {
        car.tableNumber = tableNumber;
      }

      await saveCars(cars);
      res.json(car);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST update car status (staff dashboard)
  app.post("/api/cars/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { status, keyTag } = req.body;

      const cars = await getCars();
      const index = cars.findIndex((c) => c.id === id);
      if (index === -1) {
        return res.status(404).json({ error: "Car not found" });
      }

      const car = cars[index];
      if (status) {
        car.status = status;
        if (status === "READY") {
          car.readyAt = new Date().toISOString();
        } else if (status === "DELIVERED") {
          car.deliveredAt = new Date().toISOString();
        }
      }
      if (keyTag !== undefined) {
        car.keyTag = keyTag;
      }

      await saveCars(cars);
      res.json(car);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST search/lookup car by plate or ticket number
  app.post("/api/cars/lookup", async (req, res) => {
    try {
      const { query } = req.body;
      if (!query) {
        return res.status(400).json({ error: "Query is required" });
      }

      const cars = await getCars();
      const normalizedQuery = query.trim().toUpperCase();

      const results = cars.filter((c) => {
        const matchesTicket = c.id.toUpperCase() === normalizedQuery;
        const matchesPlate = c.plate === normalizedQuery;
        return (matchesTicket || matchesPlate) && c.status !== "DELIVERED";
      });

      res.json(results);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST reset data
  app.post("/api/cars/reset", async (req, res) => {
    try {
      await saveCars([]);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET admin settings
  app.get("/api/admin/settings", async (req, res) => {
    try {
      const settings = await getSettings();
      res.json({
        hasPasscode: !!settings.adminPasscode,
        devices: settings.devices,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST verify passcode
  app.post("/api/admin/verify", async (req, res) => {
    try {
      const { passcode, deviceId, name } = req.body;
      if (!passcode) {
        return res.status(400).json({ error: "Passcode is required" });
      }

      const settings = await getSettings();
      if (settings.adminPasscode === passcode.trim()) {
        if (deviceId) {
          const index = settings.devices.findIndex((d) => d.deviceId === deviceId);
          if (index !== -1) {
            settings.devices[index].role = "manager";
            settings.devices[index].lastActive = new Date().toISOString();
            if (name) settings.devices[index].name = name;
          } else {
            settings.devices.push({
              deviceId,
              name: name || "Admin Console",
              role: "manager",
              lastActive: new Date().toISOString(),
            });
          }
          await saveSettings(settings);
        }
        return res.json({ success: true, role: "manager" });
      } else {
        return res.status(401).json({ error: "Incorrect passcode" });
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST update passcode
  app.post("/api/admin/update-passcode", async (req, res) => {
    try {
      const { currentPasscode, newPasscode } = req.body;
      if (!currentPasscode || !newPasscode) {
        return res.status(400).json({ error: "Current and new passcode are required" });
      }

      const settings = await getSettings();
      if (settings.adminPasscode !== currentPasscode.trim()) {
        return res.status(401).json({ error: "Incorrect current passcode" });
      }

      settings.adminPasscode = newPasscode.trim();
      await saveSettings(settings);
      res.json({ success: true, message: "Passcode updated successfully" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST register device / fetch its role
  app.post("/api/admin/devices/register", async (req, res) => {
    try {
      const { deviceId, name, forceRole } = req.body;
      if (!deviceId) {
        return res.status(400).json({ error: "deviceId is required" });
      }

      const settings = await getSettings();
      let index = settings.devices.findIndex((d) => d.deviceId === deviceId);
      
      let role: any = "guest";
      if (index !== -1) {
        if (forceRole) {
          settings.devices[index].role = forceRole;
        }
        settings.devices[index].lastActive = new Date().toISOString();
        if (name) settings.devices[index].name = name;
        role = settings.devices[index].role;
      } else {
        const defaultRole = forceRole || "guest";
        settings.devices.push({
          deviceId,
          name: name || `Device-${deviceId.slice(0, 4)}`,
          role: defaultRole,
          lastActive: new Date().toISOString(),
        });
        role = defaultRole;
      }

      await saveSettings(settings);
      res.json({ success: true, role });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST assign role to specific device
  app.post("/api/admin/devices/assign", async (req, res) => {
    try {
      const { targetDeviceId, role, name } = req.body;
      if (!targetDeviceId || !role) {
        return res.status(400).json({ error: "targetDeviceId and role are required" });
      }

      const settings = await getSettings();
      let index = settings.devices.findIndex((d) => d.deviceId === targetDeviceId);
      
      if (index !== -1) {
        settings.devices[index].role = role;
        settings.devices[index].lastActive = new Date().toISOString();
        if (name) settings.devices[index].name = name;
      } else {
        settings.devices.push({
          deviceId: targetDeviceId,
          name: name || `Device-${targetDeviceId.slice(0, 4)}`,
          role,
          lastActive: new Date().toISOString(),
        });
      }

      await saveSettings(settings);
      res.json({ success: true, devices: settings.devices });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST remove/revoke device
  app.post("/api/admin/devices/revoke", async (req, res) => {
    try {
      const { targetDeviceId } = req.body;
      if (!targetDeviceId) {
        return res.status(400).json({ error: "targetDeviceId is required" });
      }

      const settings = await getSettings();
      settings.devices = settings.devices.filter((d) => d.deviceId !== targetDeviceId);
      await saveSettings(settings);
      res.json({ success: true, devices: settings.devices });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
